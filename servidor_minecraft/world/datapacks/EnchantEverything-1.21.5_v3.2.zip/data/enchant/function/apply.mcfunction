execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:mending 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:mending

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:unbreaking 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:unbreaking

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:protection 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:protection

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:projectile_protection 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:projectileprotection

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:blast_protection 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:blastprotection

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:fire_protection 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:fireprotection

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:thorns 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:thorns

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:aqua_affinity 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:aquaaffinity

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:respiration 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:respiration

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:swift_sneak 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:swiftsneak

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:depth_strider 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:depthstrider

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:feather_falling 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:featherfalling

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:frost_walker 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:frostwalker

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:soul_speed 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:soulspeed

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:sharpness 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:sharpness

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:smite 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:smite

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:bane_of_arthropods 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:baneofarthropods

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:looting 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:looting

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:sweeping_edge 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:sweepingedge

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:knockback 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:knockback

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:fire_aspect 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:fireaspect

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:impaling 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:impaling

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:channeling 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:channeling

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:riptide 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:riptide

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:loyalty 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:loyalty

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:power 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:power

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:infinity 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:infinity

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:flame 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:flame

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:punch 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:punch

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:multishot 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:multishot

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:piercing 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:piercing

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:quick_charge 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:quickcharge

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:efficiency 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:efficiency

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:fortune 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:fortune

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:silk_touch 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:silktouch

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:lure 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:lure

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:luck_of_the_sea 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:luckofthesea

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:density 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:density

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:breach 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:breach

scoreboard players set @s TestEnchant 0


execute store success score @s TestEnchant run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:wind_burst 1

execute if score @s TestEnchant matches 1 run execute as @e[type=item,limit=1,sort=nearest,distance=..4,nbt=!{Item:{id:"minecraft:enchanted_book"}}] run function do-not-use:windburst

scoreboard players set @s TestEnchant 0