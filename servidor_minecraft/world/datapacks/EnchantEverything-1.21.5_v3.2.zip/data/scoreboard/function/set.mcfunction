scoreboard objectives add TestEnchant dummy "TestEnchant"
schedule function command:loop 1s