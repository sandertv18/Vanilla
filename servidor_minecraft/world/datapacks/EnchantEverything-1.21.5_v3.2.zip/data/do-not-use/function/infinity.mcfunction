execute store result entity @s Item.components.minecraft:enchantments.minecraft:infinity int 1 at @s run data get entity @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}] Item.components.minecraft:stored_enchantments.minecraft:infinity 1

execute at @s run kill @e[type=item,limit=1,sort=nearest,distance=..0.5,nbt={Item:{id:"minecraft:enchanted_book"}}]