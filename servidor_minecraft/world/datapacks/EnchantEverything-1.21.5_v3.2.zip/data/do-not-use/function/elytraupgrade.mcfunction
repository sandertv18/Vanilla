data modify entity @s Item.components.minecraft:attribute_modifiers append value {type:'minecraft:armor',amount:8.0,slot:"chest",id:"enchanteverythingelytra1",operation:'add_value'}
data modify entity @s Item.components.minecraft:attribute_modifiers append value {type:'minecraft:armor_toughness',amount:3.0,slot:"chest",id:"enchanteverythingelytra2",operation:'add_value'}
data modify entity @s Item.components.minecraft:attribute_modifiers append value {type:'minecraft:knockback_resistance',amount:0.1,slot:"chest",id:"enchanteverythingelytra3",operation:'add_value'}

execute at @s run kill @e[type=item,sort=nearest,limit=1,distance=..0.5,nbt={Item:{id:"minecraft:netherite_ingot",count:1}}]