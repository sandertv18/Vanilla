execute as @a at @s if block ~ ~-1 ~ #minecraft:anvil run function enchant:apply
execute as @a at @s if block ~ ~-1 ~ minecraft:grindstone run function enchant:remove
execute as @a at @s if block ~ ~-1 ~ minecraft:gold_block run function repaircost:reset
execute as @a at @s if block ~ ~-1 ~ minecraft:end_stone run function elytra:upgrade
schedule function command:loop 1s