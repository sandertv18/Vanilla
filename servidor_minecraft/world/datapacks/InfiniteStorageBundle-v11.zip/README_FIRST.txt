### README ###

## License Information ##

This mod/datapack is licensed under **All Rights Reserved**. You are allowed to use it for personal enjoyment and to include it in modpacks. Personal modifications are also permitted. However, redistribution and reuploading of this mod/datapack are strictly prohibited. Sharing is only allowed through the official links provided below:

- CurseForge 1:	https://www.curseforge.com/minecraft/mc-mods/infinite-storage-bundle
- CUrseForge 2:	https://www.curseforge.com/minecraft/data-packs/infinite-storage-bundle
- Modrinth:	https://modrinth.com/datapack/infinite-storage-bundle

If you have obtained this file from any source other than the official links mentioned above, it may have been stolen and could contain malware or viruses. Always download from official sources to ensure the safety and integrity of your system.

Please credit the original author, sashiro, if you reference or showcase this mod/datapack.

Thank you for respecting the terms of use.
