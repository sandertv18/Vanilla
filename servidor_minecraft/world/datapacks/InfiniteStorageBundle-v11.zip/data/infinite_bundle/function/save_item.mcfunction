# Default Bundle
data modify entity @s Item.components.minecraft:bundle_contents prepend from entity @e[type=item,limit=1,sort=nearest,distance=0.1..0.5] Item
kill @e[type=item,limit=1,sort=nearest,distance=0.1..0.5]