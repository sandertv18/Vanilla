# White Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:white_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Light Gray Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:light_gray_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Gray Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:gray_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Black Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:black_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Brown Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:brown_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Red Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:red_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Orange Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:orange_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Yellow Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:yellow_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Lime Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:lime_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Green Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:green_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Cyan Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:cyan_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Light Blue Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:light_blue_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Blue Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:blue_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Purple Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:purple_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Magenta Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:magenta_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Pink Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:pink_bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item

# Default Bundle
execute as @e[limit=1,sort=nearest,type=item,nbt={Item:{id:"minecraft:bundle"},OnGround:1b}] at @s run function infinite_bundle:save_item